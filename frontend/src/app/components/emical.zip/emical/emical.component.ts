import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emical',
  templateUrl: './emical.component.html',
  styleUrls: ['./emical.component.css']
})
export class EmicalComponent implements OnInit {

  constructor() { }

  optionsSelected: string;
  carat22:any=4492;
  carat24:any=4900;
  netweight:any;
  carat:any;
  amt:any=0;
  ngOnInit(): void {
  }

  onCalculate(e:any,e1:any) {

    this.optionsSelected = e.target.value;
    this.carat=e1.target.value;
    if (this.optionsSelected == 'Necklace' && this.carat=="24") {
          console.log(this.carat24);
           this.amt=this.netweight*this.carat24;
    }
    console.log(this.amt)
    
  }

}
